﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Jojatekok.PoloniexAPI;
using Jojatekok.PoloniexAPI.MarketTools;
using MahApps.Metro.IconPacks;
using System.Threading;
using MahApps.Metro;
using MahApps.Metro.Controls.Dialogs;
using MahApps.Metro.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using LiteDB;
using System.Windows.Threading;
using PoloniexAutoTrader.Strategies;

namespace PoloniexAutoTrader
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public PoloniexClient PoloniexClient { get; set; }


        // Set Symbol 1 from combobox  
        private string symbol;
        private string symbol1;
        // Symbol 2 from combo box selction
        private string symbol2;
        private MarketPeriod marketseries;
        private double IBS;
        double range_adr;
        private double priceLimit;
        private double quantity;
        private double currentTickerPrice;
        private string orderID;
        public string Filename;

        //Min order size
        private double minOrderSize = 0.001;

        public MainWindow()
        {
            InitializeComponent();

            //PoloniexClient = new PoloniexClient(ApiKeys.PublicKey, ApiKeys.PrivateKey);
            PoloniexClient = new PoloniexClient(Properties.Settings.Default.PublicKey, Properties.Settings.Default.PrivateKey);
            Application.Current.Properties.Add("PoloniexClient", PoloniexClient);
            //PoloniexClient = (PoloniexClient)Application.Current.Properties["PoloniexClient"];

            //Display Current Time
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += timer_Tick;
            timer.Start();

        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await GetBalanceBTC();
        }

        //***************************************************************************************

        #region API Keys
        //Set API Keys
        private void APIKeySetButton_Click(object sender, RoutedEventArgs e)
        {
            var ApiKey_Window = new ApiKey_Window();
            ApiKey_Window.Show();
        }
        #endregion

        //***************************************************************************************

        #region Currency Pair Method
        // Get Currency pair from symbol strings
        public CurrencyPair GetSymbolCode(string symbol1, string symbol2)
        {
            CurrencyPair symbol = new CurrencyPair(symbol1, symbol2);
            return symbol;
        }
        #endregion

        //***************************************************************************************

        void timer_Tick(object sender, EventArgs e)
        {
            ShowTime.Text = DateTime.Now.ToShortTimeString();
        }

        //***************************************************************************************

        #region Display Balances and Current Price

        // Get / Set and return BTC balance
        private async Task<double> GetBalanceBTC()
        {
            double balanceBTC = 0;
            var wallet = await PoloniexClient.Wallet.GetBalancesAsync();

            foreach (var b in wallet)
            {
                if (b.Key == "BTC")
                    ShowBalanceStatus.Text = b.Value.BitcoinValue.ToStringNormalized() + " BTC";
                    balanceBTC = b.Value.BitcoinValue;
            }
            return balanceBTC;

        }

        // Get / Set and return Quote balance
        private async Task<double> GetBalanceQuote()
        {
            double balanceQuote = 0;
            var wallet = await PoloniexClient.Wallet.GetBalancesAsync();

            foreach (var b in wallet)
            {
                if (b.Key == symbol2)
                {
                    //BalanceDisplayQuote.Text = b.Value.QuoteAvailable.ToString();
                    //QuoteValue.Text = b.Value.BitcoinValue.ToStringNormalized();
                    //balanceQuote = b.Value.BitcoinValue;
                }
            }
            return balanceQuote;

        }

        #endregion
        //***************************************************************************************


        //MarketSeries ComboBox
        private void MarketSeriesSelect_Loaded(object sender, RoutedEventArgs e)
        {
            // ... A List.
            List<MarketPeriod> marketseriesList = new List<MarketPeriod>();
            marketseriesList.Add(MarketPeriod.Minutes5);
            marketseriesList.Add(MarketPeriod.Minutes15);
            marketseriesList.Add(MarketPeriod.Minutes30);
            marketseriesList.Add(MarketPeriod.Hours2);
            marketseriesList.Add(MarketPeriod.Hours4);
            marketseriesList.Add(MarketPeriod.Day);

            var comboBox = sender as ComboBox;

            comboBox.Items.Clear();

            comboBox.ItemsSource = marketseriesList;

            comboBox.SelectedIndex = 5;

        }

        //MarketSeries ComboBox Selection
        private void MarketSeriesSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // ... Get the ComboBox.
            var comboBox = sender as ComboBox;
            // ... Set SelectedItem MarketSeries
            marketseries = (MarketPeriod)(comboBox.SelectedItem);
        }

        //***************************************************************************************


        //Zero balance checkbox - Checkced
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            Handle(sender as CheckBox);
        }

        //Zero balance checkbox - Uncheckced
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            Handle(sender as CheckBox);
        }

        //
        void Handle(CheckBox checkBox)
        {
            // Refresh balance
            //BalanceGrid.Items.Refresh();
        }

        //***************************************************************************************

        #region Setting Symbols

        
        private async void SymbolSelect_Loaded(object sender, RoutedEventArgs e)
        {
            IDictionary<CurrencyPair, IMarketData> markets = await GetMarketInfo();
            List<CurrencyPair> symbolList = new List<CurrencyPair>();

        foreach (var symbols in (markets.OrderBy(i => i.Key.QuoteCurrency)))
        {
            symbolList.Add(symbols.Key);
        }

            var comboBox = sender as ComboBox;

            comboBox.Items.Clear();

            comboBox.ItemsSource = symbolList;

            comboBox.SelectedIndex = 0;
        }

        //Symbol changed
        void SymbolSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SaveSymbols(sender as ComboBox);
        }

        void QuoteSymbolSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SaveSymbols(sender as ComboBox);
        }

        private void SaveSymbols(ComboBox comboBox)
        {
            symbol = comboBox.SelectedItem as string;
        }

        #endregion

        //***************************************************************************************


        #region Submit Orders
        // Method to get market data
        private async Task<IDictionary<CurrencyPair, IMarketData>> GetMarketInfo()
        {
            return await PoloniexClient.Markets.GetSummaryAsync();
        }

        // Execute Limit Order
        public async Task ExecuteLimitOrder(string symbol1, string symbol2, OrderType orderType)
        {
            CurrencyPair symbol = GetSymbolCode(symbol1, symbol2);

            if (orderType == OrderType.Buy)
            {
                var ExecuteBuyOrder = await PoloniexClient.Trading.PostOrderAsync(symbol, OrderType.Buy, priceLimit, quantity);
            }
            else if (orderType == OrderType.Sell)
            {
                var ExecuteSellOrder = await PoloniexClient.Trading.PostOrderAsync(symbol, OrderType.Sell, priceLimit, quantity);
            }
        }

        // Execute Market Order from top of order book
        public async Task ExecuteMarketOrder(string symbol1, string symbol2, OrderType orderType, double quantity)
        {
            CurrencyPair symbol = GetSymbolCode(symbol1, symbol2);
            IDictionary<CurrencyPair, IMarketData> marketinfo = await GetMarketInfo();

            if (orderType == OrderType.Buy)
            {
                double currentPrice = CurrentMarketPrice(symbol1, symbol2, OrderType.Buy, marketinfo);
                var ExecuteBuyOrder = await PoloniexClient.Trading.PostOrderAsync(symbol, OrderType.Buy, currentPrice, quantity);

            }
            else if (orderType == OrderType.Sell)
            {
                double currentPrice = CurrentMarketPrice(symbol1, symbol2, OrderType.Sell, marketinfo);
                var ExecuteSellOrder = await PoloniexClient.Trading.PostOrderAsync(symbol, OrderType.Sell, currentPrice, quantity);
            }
        }

        //***************************************************************************************

        //Get Top OrderBook Quote
        private static double CurrentMarketPrice(string symbol1, string symbol2, OrderType orderType, IDictionary<CurrencyPair, IMarketData> marketinfo)
        {
            double price = 0;

            foreach (var m in marketinfo)
            {
                if (m.Key.BaseCurrency == symbol1 && m.Key.QuoteCurrency == symbol2)
                {
                    if (orderType == OrderType.Buy)
                    {
                        price = m.Value.OrderTopBuy;
                    }
                    else if (orderType == OrderType.Sell)
                    {
                        price = m.Value.OrderTopBuy;
                    }
                }
            }
            return price;
        }

        private void Total_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        //***************************************************************************************

        private async Task DialogBoxStrategy(string strategyName, string state)
        {
            var mySettings = new MetroDialogSettings()
            {
                AffirmativeButtonText = "OK",
                ColorScheme = MetroDialogOptions.ColorScheme
            };

            MessageDialogResult result = await this.ShowMessageAsync(strategyName, strategyName + " " + state + " Successfully",
            MessageDialogStyle.Affirmative, mySettings);

            if (result == MessageDialogResult.Affirmative)
            {
                // Run Strategy 1

            }
        

        }

        // Start Strategy 1
        private async void Strategy1Start_Click(object sender, RoutedEventArgs e)
        {
            BlackSwan blackswan = new BlackSwan();

            string strategyName = StrategyName1.Content.ToString();            
            MarketPeriod marketSeries = (MarketPeriod)(MarketSeriesSelect1.SelectedItem);
            CurrencyPair symbol = (CurrencyPair)Strategy2Symbol.SelectedItem;
            double volume = double.Parse(Strategy1Total.Text);
            bool? buy = Strategy1Buy.IsChecked;
            bool? sell = Strategy1Sell.IsChecked;

            blackswan.BlackSwanSettings(strategyName, marketSeries, symbol, buy, sell, volume);

            await DialogBoxStrategy(StrategyName1.Content.ToString(), "Started");
        }
        // Start Strategy 2
        private async void Strategy2Start_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName2.Content.ToString(), "Started");
        }
        // Start Strategy 3
        private async void Strategy3Start_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName3.Content.ToString(), "Started");
        }
        // Start Strategy 4
        private async void Strategy4Start_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName4.Content.ToString(), "Started");
        }

        // Stop Strategy 1
        private async void Strategy1Stop_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName1.Content.ToString(), "Stopped");
        }
        // Stop Strategy 1
        private async void Strategy2Stop_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName2.Content.ToString(), "Stopped");
        }
        // Stop Strategy 1
        private async void Strategy3Stop_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName3.Content.ToString(), "Stopped");
        }
        // Stop Strategy 1
        private async void Strategy4Stop_Click(object sender, RoutedEventArgs e)
        {
            await DialogBoxStrategy(StrategyName4.Content.ToString(), "Stopped");
        }
        #endregion

        //***************************************************************************************


    }
}
