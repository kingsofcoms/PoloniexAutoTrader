﻿using Jojatekok.PoloniexAPI;
using Jojatekok.PoloniexAPI.MarketTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoloniexAutoTrader.Strategies
{
    class IBS
    {
        public string Name { get; set; }
        public MarketPeriod MarketSeries { get; set; }
        public CurrencyPair Symbol { get; set; }
        public bool Buy { get; set; }
        public bool Sell { get; set; }
        public double Volume { get; set; }
    }
}
