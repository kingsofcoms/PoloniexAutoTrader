﻿using Jojatekok.PoloniexAPI;
using Jojatekok.PoloniexAPI.MarketTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoloniexAutoTrader.Strategies
{   
    class BlackSwan
    {

        public string StrategyName;
        public MarketPeriod MarketSeries;
        public CurrencyPair Symbol;
        public bool? Buy;
        public bool? Sell;
        public double Volume;

        public void BlackSwanSettings(string strategyName, MarketPeriod marketseries, CurrencyPair symbol, bool? buy, bool? sell, double volume)
        {
            StrategyName = strategyName;
            MarketSeries = marketseries;
            Symbol = symbol;
            Buy = buy;
            Sell = sell;
            Volume = volume;

        }


        /*
        public string StrategyName { get; set; }
        public MarketPeriod MarketSeries { get; set; }
        public CurrencyPair Symbol { get; set; }
        public bool Buy { get; set; }
        public bool Sell { get; set; }
        public double Volume { get; set; }*/
    }
}
